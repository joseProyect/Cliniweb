<?php
// Archivo: gestioncitas.php

// Incluir la clase Database
include('../../CONEXION/Database.php');

// Crear una instancia de la clase Database y obtener la conexión
$db = new Database();
$conn = $db->getConnection(); // Obtenemos la conexión PDO

// Verificar si la conexión fue exitosa
if (!$conn) {
    die("Error: No se pudo conectar a la base de datos.");
}

// Consulta para obtener las citas
$query = "SELECT c.id, p.nombre AS paciente, d.nombre AS doctor, c.fecha, c.hora, c.estado, c.descripcion
          FROM Citas c
          JOIN Pacientes p ON c.paciente_id = p.id
          LEFT JOIN Usuarios d ON c.doctor_id = d.id";
$stmt = $conn->prepare($query);

try {
    $stmt->execute();
    $citas = $stmt->fetchAll(); // Obtener todos los resultados
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Citas</title>
    <link rel="stylesheet" href="../TABLASCSS/citas.css">
</head>
<body>
<div class="container">
    <h1>Gestión de Citas</h1>
    <button id="agregar-cita-btn">Agregar Cita</button>

    <!-- Tabla de citas -->
    <table>
        <thead>
        <tr>
            <th>Paciente</th>
            <th>Doctor</th>
            <th>Fecha</th>
            <th>Hora</th>
            <th>Estado</th>
            <th>Descripción</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($citas as $cita) { ?>
            <tr data-id="<?php echo $cita['id']; ?>">
                <td><?php echo htmlspecialchars($cita['paciente']); ?></td>
                <td><?php echo htmlspecialchars($cita['doctor']); ?></td>
                <td><?php echo htmlspecialchars($cita['fecha']); ?></td>
                <td><?php echo htmlspecialchars($cita['hora']); ?></td>
                <td><?php echo htmlspecialchars($cita['estado']); ?></td>
                <td><?php echo htmlspecialchars($cita['descripcion']); ?></td>
                <td class="actions">
                    <a href="#" class="edit" data-id="<?php echo $cita['id']; ?>">Editar</a>
                    <a href="#" class="delete" data-id="<?php echo $cita['id']; ?>">Eliminar</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<!-- Modal para agregar/editar citas -->
<div id="formulario-cita" class="modal">
    <div class="modal-content">
        <h2 id="modal-title">Agregar Cita</h2>
        <form id="form-cita">
            <input type="hidden" name="cita_id" id="cita-id">
            <label for="paciente">Paciente:</label>
            <input type="text" id="paciente" name="paciente" required>

            <label for="doctor">Doctor:</label>
            <input type="text" id="doctor" name="doctor" required>

            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>

            <label for="hora">Hora:</label>
            <input type="time" id="hora" name="hora" required>

            <label for="estado">Estado:</label>
            <select id="estado" name="estado">
                <option value="pendiente">Pendiente</option>
                <option value="confirmada">Confirmada</option>
                <option value="cancelada">Cancelada</option>
            </select>

            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion"></textarea>

            <div class="form-buttons">
                <button type="submit" id="guardar-btn">Guardar</button>
                <button type="button" id="cancelar-btn">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<script src="../JAVASCRIPT/citas.js"></script>
</body>
</html>
