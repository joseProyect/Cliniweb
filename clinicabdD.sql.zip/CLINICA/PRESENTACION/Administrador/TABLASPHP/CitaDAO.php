<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../../CONEXION/Database.php');

$db = new Database();
$conn = $db->getConnection();

header('Content-Type: application/json'); // Configuración de la respuesta en formato JSON

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error en la conexión a la base de datos.']);
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['cita_id']) && !empty($_POST['cita_id'])) {
            // Actualizar una cita existente
            $stmt = $conn->prepare("UPDATE Citas SET paciente_id = :paciente, doctor_id = :doctor, fecha = :fecha, hora = :hora, estado = :estado, descripcion = :descripcion WHERE id = :id");
            $stmt->bindParam(':paciente', $_POST['paciente']);
            $stmt->bindParam(':doctor', $_POST['doctor']);
            $stmt->bindParam(':fecha', $_POST['fecha']);
            $stmt->bindParam(':hora', $_POST['hora']);
            $stmt->bindParam(':estado', $_POST['estado']);
            $stmt->bindParam(':descripcion', $_POST['descripcion']);
            $stmt->bindParam(':id', $_POST['cita_id']);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Cita actualizada correctamente.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al actualizar la cita.']);
            }
        } else {
            // Agregar una nueva cita
            if (!empty($_POST['paciente']) && !empty($_POST['doctor']) && !empty($_POST['fecha']) && !empty($_POST['hora']) && !empty($_POST['estado'])) {
                $stmt = $conn->prepare("INSERT INTO Citas (paciente_id, doctor_id, fecha, hora, estado, descripcion) VALUES (:paciente, :doctor, :fecha, :hora, :estado, :descripcion)");
                $stmt->bindParam(':paciente', $_POST['paciente']);
                $stmt->bindParam(':doctor', $_POST['doctor']);
                $stmt->bindParam(':fecha', $_POST['fecha']);
                $stmt->bindParam(':hora', $_POST['hora']);
                $stmt->bindParam(':estado', $_POST['estado']);
                $stmt->bindParam(':descripcion', $_POST['descripcion']);

                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Cita agregada correctamente.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Error al agregar la cita.']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Todos los campos son requeridos.']);
            }
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Eliminar una cita
        $delete_vars = json_decode(file_get_contents("php://input"), true); // Lee el cuerpo como JSON
        if (isset($delete_vars['id']) && !empty($delete_vars['id'])) {
            $stmt = $conn->prepare("DELETE FROM Citas WHERE id = :id");
            $stmt->bindParam(':id', $delete_vars['id']);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'Cita eliminada correctamente.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al eliminar la cita.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'ID de cita no especificado.']);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
        // Obtener los datos de una cita específica
        $stmt = $conn->prepare("SELECT * FROM Citas WHERE id = :id");
        $stmt->bindParam(':id', $_GET['id']);

        if ($stmt->execute()) {
            $cita = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cita) {
                echo json_encode($cita);
            } else {
                echo json_encode(['success' => false, 'message' => 'Cita no encontrada.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Error al obtener la cita.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error en el servidor: ' . $e->getMessage()]);
}

?>
