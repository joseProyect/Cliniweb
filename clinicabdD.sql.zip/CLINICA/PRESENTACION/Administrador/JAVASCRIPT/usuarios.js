document.addEventListener('DOMContentLoaded', function () {
    const agregarUsuarioBtn = document.getElementById('agregar-usuario-btn');
    const editarUsuarioBtn = document.getElementById('editar-usuario-btn');
    const eliminarUsuarioBtn = document.getElementById('eliminar-usuario-btn');
    const formularioAgregar = document.getElementById('formulario-agregar');
    const formAgregar = document.getElementById('form-agregar-usuario');
    const cancelarBtn = document.getElementById('cancelar-btn');

    function obtenerUsuariosSeleccionados() {
        return document.querySelectorAll('.select-user:checked');
    }

    // Mostrar el formulario de agregar usuario
    agregarUsuarioBtn.addEventListener('click', function () {
        formularioAgregar.style.display = 'block';
    });

    // Ocultar el formulario de agregar usuario al cancelar
    cancelarBtn.addEventListener('click', function () {
        formularioAgregar.style.display = 'none';
    });

    // Enviar formulario de agregar usuario
    formAgregar.addEventListener('submit', function (event) {
        event.preventDefault();
        const formData = new FormData(formAgregar);

        fetch('UsuarioDAO.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Usuario agregado correctamente');
                formularioAgregar.style.display = 'none';
                location.reload();
            } else {
                alert('Error al agregar el usuario.');
            }
        })
        .catch(error => {
            console.error('Error en la solicitud:', error);
            alert('Hubo un problema al agregar el usuario.');
        });
    });

    // Editar usuario
    editarUsuarioBtn.addEventListener('click', function () {
        const selectedUsers = obtenerUsuariosSeleccionados();
        if (selectedUsers.length === 1) {
            const userId = selectedUsers[0].dataset.id;
            fetch(`UsuarioDAO.php?id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('usuario-id').value = data.id;
                        document.getElementById('nombre').value = data.nombre;
                        document.getElementById('email').value = data.email;
                        formularioAgregar.style.display = 'block';
                    }
                })
                .catch(error => console.error('Error al cargar los datos:', error));
        } else {
            alert('Selecciona solo un usuario para editar.');
        }
    });

    // Eliminar usuarios seleccionados
    eliminarUsuarioBtn.addEventListener('click', function () {
        const selectedUsers = obtenerUsuariosSeleccionados();
        if (selectedUsers.length > 0) {
            if (confirm('¿Deseas eliminar los usuarios seleccionados?')) {
                selectedUsers.forEach(user => {
                    const userId = user.dataset.id;
                    fetch(`UsuarioDAO.php?id=${userId}`, {
                        method: 'DELETE'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`Usuario ${userId} eliminado`);
                            location.reload();
                        }
                    })
                    .catch(error => console.error(`Error al eliminar usuario ${userId}:`, error));
                });
            }
        } else {
            alert('Selecciona al menos un usuario para eliminar.');
        }
    });
});
